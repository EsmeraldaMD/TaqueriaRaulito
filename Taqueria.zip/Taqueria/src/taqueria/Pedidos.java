package taqueria;

import java.util.Scanner;

/**
 * @author Raul
 */
public class Pedidos {

    Scanner obj = new Scanner(System.in);

    int tipo, cuenta, pago, cambio, sumaT, sumaTotal, sumaG, sumaC, sumaN, sumaQ;

    public Pedidos() {
    }

    public Pedidos(int tipo, int cuenta, int pago, int cambio, int sumaT, int SumaTotal, int sumaG, int sumaC, int sumaN, int sumaQ) {
        this.cuenta = cuenta;
        this.pago = pago;
        this.cambio = cambio;
        this.sumaT = sumaT;
        this.sumaTotal = sumaTotal;
        this.sumaG = sumaG;
        this.sumaC = sumaC;
        this.sumaN = sumaN;
        this.sumaQ = sumaQ;
    }

    public void tacos() {

        System.out.println("Ingrese el tipo del producto "
                + "\n1.-Tacos sin cebolla"
                + "\n2.-Tacos sin cilantro"
                + "\n3.-Tacos naturales");
        tipo = obj.nextInt();
        sumaT = sumaT + 20;

    }

    public void tacosQueso() {

        System.out.println("Ingrese el tipo del producto "
                + "\n1.-Tacos sin cebolla"
                + "\n2.-Tacos sin cilantro"
                + "\n3.-Tacos naturales");
        tipo = obj.nextInt();
        sumaQ = sumaQ + 25;

    }

    public void gringasYmas() {
        System.out.println("Ingrese el tipo del producto "
                + "\n1.-Sin cebolla"
                + "\n2.-Sin cilantro"
                + "\n3.-Naturales");
        tipo = obj.nextInt();
        sumaG = sumaG + 20;

    }

    public void cemitas() {
        System.out.println("Ingrese el tipo del producto "
                + "\n1.-Cemita sin cebolla"
                + "\n2.-Cemita sin cilantro"
                + "\n3.-Cemita naturales");
        tipo = obj.nextInt();
        sumaC = sumaC + 40;

    }

    public void nopales() {
        System.out.println("Ingrese el tipo del producto "
                + "\n1.-Nopal sin cebolla"
                + "\n2.-Nopal sin cilantro"
                + "\n3.-Nopal naturales");
        tipo = obj.nextInt();
        sumaN = sumaN + 30;
    }

    public int getSumaQ() {
        return sumaQ;
    }

    public void setSumaQ(int sumaQ) {
        this.sumaQ = sumaQ;
    }

    public int getSumaN() {
        return sumaN;
    }

    public void setSumaN(int sumaN) {
        this.sumaN = sumaN;
    }

    public int getSumaG() {
        return sumaG;
    }

    public void setSumaG(int sumaG) {
        this.sumaG = sumaG;
    }

    public int getSumaC() {
        return sumaC;
    }

    public void setSumaC(int sumaC) {
        this.sumaC = sumaC;
    }

    public int getSumaT() {
        return sumaT;
    }

    public void setSumaT(int sumaT) {
        this.sumaT = sumaT;
    }

    public int getSumaTotal() {
        return sumaTotal;
    }

    public void setSumaTotal(int sumaTotal) {
        this.sumaTotal = sumaT + sumaG + sumaC + sumaN + sumaQ;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getCuenta() {
        return cuenta;
    }

    public void setCuenta(int cuenta) {
        this.cuenta = cuenta;
    }

    public int getPago() {
        return pago;
    }

    public void setPago(int pago) {
        this.pago = pago;
    }

    public int getCambio() {
        return cambio;
    }

    public void setCambio(int cambio) {
        this.cambio = pago - sumaTotal;
    }

}
