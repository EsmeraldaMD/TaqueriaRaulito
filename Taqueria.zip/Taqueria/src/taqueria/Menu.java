package taqueria;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class Menu {

    public static void menu() {
        Scanner obj = new Scanner(System.in);
        Pedidos pedidos = new Pedidos();
        int cantidad, opcion, pedido;
        System.out.println("Bienvenido a la Taqueria Raulito"
                + "\n¿Cuantos productos desea comprar?");
        cantidad = obj.nextInt();
        System.out.println("Su pedido es a domicilio?"
                + "\n.1-Si"
                + "\n.2-No");
        pedido = obj.nextInt();
        if (pedido == 1) {
            System.out.println("Ingrese su domicilio");
        

            for (int i = 0; i < cantidad; i++) {
                System.out.println("\nMENU"
                        + "\n1.-Orden al pastor           $20"
                        + "\n2.-Orden al pastor con queso $25"
                        + "\n3.-Gringas al pastor         $20"
                        + "\n4.-Tortas al pastor          $20"
                        + "\n5.-Cemitas al pastor         $40"
                        + "\n6.-Nopales al pastor         $30"
                        + "\nElija una opción");
                opcion = obj.nextInt();

                switch (opcion) {
                    case 1:
                        pedidos.tacos();

                        break;
                    case 2:
                        pedidos.tacosQueso();

                        break;
                    case 3:
                        pedidos.gringasYmas();

                        break;
                    case 4:
                        pedidos.gringasYmas();

                        break;
                    case 5:
                        pedidos.cemitas();

                        break;
                    case 6:
                        pedidos.nopales();

                        break;
                    default:
                        System.out.println("Ingrese una opcion valida");
                }

               

            }
            pedidos.setSumaTotal(cantidad);
            System.out.println("Su pago total es de: " + pedidos.getSumaTotal());
            System.out.println("Ingres su pago");
            int pago = obj.nextInt();
            pedidos.setPago(pago);
            if (pedidos.getPago() >= pedidos.getSumaTotal()) {
                pedidos.setCambio(pago);

                System.out.println("Su cambio es " + pedidos.getCambio());
            } else {
                System.out.println("Su pago es insuficiente");
            }
        } else {
            System.out.println("Ingrese una opcion valida");
        }
}

}
