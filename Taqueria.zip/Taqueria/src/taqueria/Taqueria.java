package taqueria;

/**
 * Autor Raul
 */
public class Taqueria {

    public static void main(String[] args) {
         Menu menu = new Menu();
        char i=1;
        while ( i !=0) {            
            menu.menu();
        }
       

    }

}
